CREATE VIEW filenameview
as
select * from flag_filenames;

