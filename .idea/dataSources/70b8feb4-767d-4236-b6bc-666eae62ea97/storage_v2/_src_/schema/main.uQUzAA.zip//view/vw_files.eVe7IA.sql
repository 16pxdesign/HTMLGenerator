CREATE VIEW vw_files
as
select 
  substr( field1, 1, 2 )       as countrycode
, field1                       as filename
, 'readfile(' || field1 || ')' as pngname
from flag_filenames;

