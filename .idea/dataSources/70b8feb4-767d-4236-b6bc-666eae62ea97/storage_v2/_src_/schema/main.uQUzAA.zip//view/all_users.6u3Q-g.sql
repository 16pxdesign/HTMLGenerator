CREATE VIEW all_users as select c1.id, c1.first_name, c1.last_name, c1.email, c1.category, c1.countrycode from contacts c1;

